# Olist student examples — 9 October 2026

Run Jupyter from this directory with a PySpark kernel and an Iceberg runtime matching Spark. These three notebooks use copied records from our replayed Odoo/Olist exports; the original landing-zone files are unchanged.

| Notebook | Sample directory under datasets | Input rows | Accepted | Quarantined |
| --- | --- | ---: | ---: | ---: |
| schema_drifting_csv_orders.ipynb | orders/olist_complex | 12 | 9 | 3 |
| schema_drifting_jsonl_order_lines.ipynb | order_lines/olist_complex | 13 | 9 | 4 |
| schema_drifting_parquet_purchases.ipynb | purchases/olist_complex | 12 | 11 | 1 |

`datasets/olist-samples.json` records the source paths, source hashes and sampled IDs. Clean samples retain the original values. Drift samples are deliberately changed teaching copies; repeated IDs across clean and drift files are intentional examples, not additional production orders.

CSV demonstrates JSON relationship cells, an added column, a missing required ID, an invalid decimal, an invalid relationship and a header-only file. JSONL demonstrates mixed `[id, name]` relationships, a nested added column, invalid IDs/amounts and a broken JSON line. Parquet demonstrates typed relationships, a missing nullable supplier relationship and a null required ID.

Each notebook follows five steps:

1. Configure Spark and the local Iceberg catalog.
2. Declare the complete target schema visibly in the notebook.
3. Read with ordinary Spark and show a small sample.
4. Call `exploration.py` and write measurements to `datalake.operations.explorations`.
5. Optionally call `schema_drift.py` and inspect the file audits.

Set `RUN_SCHEMA_DRIFT = False`, or comment out the entire optional processing cell. The ordinary reader and exploration do not import or depend on `schema_drift.py`. Native reading converts incompatible scalar values to null; it is not a replacement for validation or quarantine.

`schema_drift.py` contains its conversion helpers and Odoo adapter. CSV and JSONL calls use `odoo=True` to handle false sentinels and relationship pairs. No `schema_values.py` or `odoo_customers.py` is required for these notebooks.

`exploration.py` is independent. Its `explore_data()` returns column measurements; `write_exploration_to_iceberg()` writes them to the operations namespace, default table `explorations`. Profiling does not modify input records or write business data into Iceberg.

Environment settings:

```text
STUDENT_DATA_ROOT       defaults to ./datasets
STUDENT_OUTPUT_ROOT     defaults to ./student-output
STUDENT_SCHEMA_DRIFT    1 enables optional processing; 0 disables it
ICEBERG_SPARK_RUNTIME_JAR  path to the matching Iceberg Spark runtime
SPARK_MASTER            defaults to local[2]
```

## Verified on aadhi

All three notebooks passed with schema drift enabled and disabled: six successful executions using Spark 3.5.7 and Iceberg 1.9.2. All seven payload files reconciled in the enabled runs. The independent exploration table contains 300 measurements in each mode. The automated runner and validation artifacts are not included in this student bundle.
